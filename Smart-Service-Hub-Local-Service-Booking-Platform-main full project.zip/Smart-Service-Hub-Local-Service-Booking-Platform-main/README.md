# Smart Service Hub – Local Service Booking Platform

Smart Service Hub is a full-stack web application that connects customers with local service providers.  
Users can register, log in, and book services, while service providers can manage service requests.

---

## 🚀 Tech Stack

### Frontend
- React (Vite)
- JavaScript
- HTML, CSS
- Fetch API

### Backend
- Spring Boot
- Hibernate (JPA)
- REST APIs
- BCrypt Password Encryption

### Database
- MySQL

## 📁 Project Structure
Smart-Service-Hub-Local-Service-Booking-Platform/

│
├── frontend/ # Vite + React frontend
│

├── backend/ # Spring Boot backend
│

└── README.md


## Configure Database
Update `application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/smart_service_hub
spring.datasource.username=root
spring.datasource.password=your_password

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true


## Run Backend 
- cd backend
- mvn spring-boot:run
http://localhost:8080

## Run Frontend in new terminal
- cd frontend
- npm run dev
http://localhost:5173


http://localhost:8080

